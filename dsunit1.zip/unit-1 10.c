//10. Write a Program to Multiply Two Matrices
#include<stdio.h>
#include<conio.h>

void main()
{
    int a[10][10], b[10][10], c[10][10];
    int r1, c1, r2, c2;
    int i, j, k;



    printf("Enter rows and columns of first matrix: ");
    scanf("%d%d", &r1, &c1);

    printf("Enter rows and columns of second matrix: ");
    scanf("%d%d", &r2, &c2);

    if(c1 != r2)
    {
        printf("Matrix multiplication is not possible.");
    }
    else
    {
        printf("Enter elements of first matrix:\n");

        for(i=0; i<r1; i++)
        {
            for(j=0; j<c1; j++)
            {
                scanf("%d", &a[i][j]);
            }
        }

        printf("Enter elements of second matrix:\n");

        for(i=0; i<r2; i++)
        {
            for(j=0; j<c2; j++)
            {
                scanf("%d", &b[i][j]);
            }
        }

        for(i=0; i<r1; i++)
        {
            for(j=0; j<c2; j++)
            {
                c[i][j] = 0;

                for(k=0; k<c1; k++)
                {
                    c[i][j] = c[i][j] + (a[i][k] * b[k][j]);
                }
            }
        }

        printf("\nResultant Matrix:\n");

        for(i=0; i<r1; i++)
        {
            for(j=0; j<c2; j++)
            {
                printf("%d\t", c[i][j]);
            }
            printf("\n");
        }
    }

    getch();
}
